from typing import TYPE_CHECKING

from deepseek_pow.solvers import BaseSolver, SOLVER_TYPES
from deepseek_pow.exceptions import UnsupportedAlgorithmError



class AlgorithmRegistry:
    """管理算法标识和求解器之间的映射."""

    def __init__(self) -> None:
        self._algorithms: dict[str, BaseSolver] = {}


    def register(self, algorithm: BaseSolver) -> None:
        """注册或替换一个算法实现。

        Parameters:
            algorithm:
                要注册的算法实例。其 ``name`` 属性作为服务端算法标识。

        Raises:
            ValueError:
                算法名称为空。
        """
        if not algorithm.name:
            raise ValueError("算法名称不能为空")

        self._algorithms[algorithm.name] = algorithm


    def get(self, name: str) -> BaseSolver:
        """根据服务端算法标识取得实现。

        Parameters:
            name:
                服务端返回的算法标识。

        Returns:
            已注册的算法实例。

        Raises:
            UnsupportedAlgorithmError:
                没有注册对应的算法实现。
        """
        try:
            return self._algorithms[name]
        except KeyError as exc:
            raise UnsupportedAlgorithmError(
                f"不支持的 PoW 算法: {name}"
            ) from exc


registry = AlgorithmRegistry()

for Solver in SOLVER_TYPES:
    registry.register(Solver())
