class DeepSeekPowError(Exception):
    """deepseek-pow 的所有公开异常的基类."""


class InvalidChallengeError(DeepSeekPowError):
    """挑战字段缺失、类型错误或取值无效."""


class UnsupportedAlgorithmError(DeepSeekPowError):
    """服务端指定了当前库不支持的算法."""


class WasmLoadError(DeepSeekPowError):
    """WASM 文件加载、实例化或导出解析失败."""


class NoSolutionError(DeepSeekPowError):
    """底层求解器没有找到符合条件的答案."""


class SolverRuntimeError(DeepSeekPowError):
    """求解期间发生内存访问或运行时错误."""
