from typing import Optional

from pydantic.dataclasses import dataclass
from pydantic import Field


@dataclass(frozen=True, slots=True)
class Challenge:
    """一个待求解的 DeepSeek PoW 挑战。
    """

    algorithm: str = Field(description='服务端返回的算法标识，例如 ``"DeepSeekHashV1"``。')
    challenge: str = Field(description="服务端生成的挑战字符串。")
    salt: str = Field(description="构造 PoW 输入前缀时使用的盐值。")
    difficulty: int | float = Field(description="PoW 难度。具体解释由对应的算法实现负责。")
    expire_at: int | str = Field(description="挑战过期时间。该值的字符串形式可能参与哈希计算，")
    signature: Optional[str] = Field(
        default=None,
        description="服务端附带的签名。签名通常不参与本地求解，但提交答案时可能需要原样返回。"
    )
