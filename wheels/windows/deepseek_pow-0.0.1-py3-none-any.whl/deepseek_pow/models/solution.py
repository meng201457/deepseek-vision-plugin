from typing import Dict, Optional

from pydantic.dataclasses import dataclass
from pydantic import Field


@dataclass(frozen=True, slots=True)
class Solution:
    """表示 PoW 挑战的求解结果。
    """

    algorithm: str = Field(description="实际使用的算法标识。")
    challenge: str = Field(description="原始挑战字符串。")
    salt: str = Field(description="原始盐值。")
    answer: float = Field(description="求解得到的答案。")
    signature: Optional[str] = Field(
        default=None,
        description="原始签名，便于直接构造提交数据。"
    )

    def to_answer_payload(self) -> Dict[str, object]:
        """生成与浏览器 Worker 返回结构相近的答案字典。

        Returns:
            包含算法、挑战、盐、答案和签名的普通字典。
        """
        return {
            "algorithm": self.algorithm,
            "challenge": self.challenge,
            "salt": self.salt,
            "answer": self.answer,
            "signature": self.signature,
        }
