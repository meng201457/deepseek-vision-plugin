"""
数据模型
"""

from .challenge import Challenge
from .solution import Solution
