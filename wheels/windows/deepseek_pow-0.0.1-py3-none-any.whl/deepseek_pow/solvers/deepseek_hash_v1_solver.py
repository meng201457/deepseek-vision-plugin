"""
描述 V1 的输入规则及求解流程
"""

import math
import struct
from pathlib import Path
from typing import Any, override

import wasmtime

from .base import BaseSolver
from ..exceptions import WasmLoadError, SolverRuntimeError, NoSolutionError
from ..models import Challenge, Solution


DEFAULT_WASM_PATH = Path(__file__).parent.parent / "resources/sha3_wasm_v1.wasm"

class DeepSeekHashV1Solver(BaseSolver):
    """DeepSeekHashV1 WASM PoW 求解器。

    该类加载由 wasm-bindgen 生成的 WebAssembly 模块，并复现 JavaScript
    胶水层调用 ``wasm_solve`` 时使用的 ABI。

    默认情况下，求解器使用包内附带的 V1 WASM 文件。

    也可以传入自定义 WASM 文件：

    ```python
    solver = DeepSeekHashV1Solver(
        wasm_path="/path/to/sha3_wasm_v1.wasm",
    )
    ```

    WASM 模块预期至少导出以下项目：

    - ``memory``
    - ``wasm_solve``
    - ``__wbindgen_add_to_stack_pointer``
    - ``__wbindgen_export_0``，即内存分配函数
    - ``__wbindgen_export_1``，即内存重分配函数
    """

    name = "DeepSeekHashV1"

    def __init__(
        self,
        wasm_path: str | Path = DEFAULT_WASM_PATH,
    ) -> None:
        """
        Parameters:
            wasm_path:
                WASM 文件路径。默认读取当前工作目录下的
                ``sha3_wasm_bg.7b9ca65ddd.wasm``。

        Raises:
            WasmLoadError:
                指定的 WASM 文件不存在。
                WASM 实例化失败，或缺少必要导出项。
        """
        self._wasm_path = Path(wasm_path)

        if not self._wasm_path.is_file():
            raise WasmLoadError(
                f"WASM 文件不存在: {self._wasm_path.resolve()}"
            )

        self._engine = wasmtime.Engine()
        self._store = wasmtime.Store(self._engine)

        module = wasmtime.Module.from_file(
            self._engine,
            str(self._wasm_path),
        )

        # 该 WASM 的导入对象为空，因此可以直接实例化。
        self._instance = wasmtime.Instance(self._store, module, [])

        exports = self._instance.exports(self._store)

        self._memory = self._require_export(exports, "memory")
        self._wasm_solve = self._require_export(exports, "wasm_solve")
        self._add_to_stack_pointer = self._require_export(
            exports,
            "__wbindgen_add_to_stack_pointer",
        )
        self._alloc = self._require_export(
            exports,
            "__wbindgen_export_0",
        )
        self._realloc = self._require_export(
            exports,
            "__wbindgen_export_1",
        )


    @staticmethod
    def _require_export(exports: Any, name: str) -> Any:
        """取得必需的 WASM 导出项。

        Parameters:
            exports:
                ``wasmtime.Instance.exports`` 返回的导出集合。
            name:
                必须存在的导出名称。

        Returns:
            对应的导出对象，例如函数或线性内存。

        Raises:
            WasmLoadError:
                指定导出项不存在。
        """
        try:
            return exports[name]
        except KeyError as exc:
            raise WasmLoadError(
                f"WASM 缺少必要导出项: {name}"
            ) from exc


    def _write_bytes(self, data: bytes) -> tuple[int, int]:
        """将字节串分配并写入 WASM 线性内存。

        这里不需要逐字复现 JavaScript 中针对 ASCII 的编码优化。
        Python 可以先完成 UTF-8 编码，再一次性申请准确大小的内存，
        最终传给 WASM 的指针和字节长度完全等价。

        Parameters:
            data:
                要写入 WASM 线性内存的原始字节串。

        Returns:
            二元组 ``(pointer, byte_length)``：

            - ``pointer`` 是 WASM 线性内存中的起始地址。
            - ``byte_length`` 是实际写入的字节数。

        Raises:
            SolverRuntimeError:
                分配器返回的地址无效，或者写入后内存范围异常。
        """
        byte_length = len(data)

        # wasm-bindgen 分配器签名为 alloc(size, align) -> pointer。
        pointer = int(self._alloc(self._store, byte_length, 1)) & 0xFFFFFFFF

        if byte_length == 0:
            return pointer, 0

        memory_size = self._memory.data_len(self._store)
        end = pointer + byte_length

        if end > memory_size:
            raise SolverRuntimeError(
                "WASM 分配器返回了超出线性内存范围的地址: "
                f"pointer={pointer}, length={byte_length}, "
                f"memory_size={memory_size}"
            )

        # write() 的第三个参数是在线性内存中的起始偏移。
        self._memory.write(self._store, data, pointer)

        return pointer, byte_length


    def _write_utf8(self, value: str) -> tuple[int, int]:
        """以 UTF-8 编码字符串并写入 WASM 线性内存。

        Parameters:
            value:
                要传入 WASM 的 Python 字符串。

        Returns:
            二元组 ``(pointer, utf8_byte_length)``。长度是 UTF-8 字节数，
            而不是 Python 字符数。

        Raises:
            TypeError:
                ``value`` 不是字符串。
            UnicodeEncodeError:
                字符串无法按严格 UTF-8 规则编码。
        """
        if not isinstance(value, str):
            raise TypeError(
                f"传入 WASM 的值必须是 str，实际为 {type(value).__name__}"
            )

        return self._write_bytes(value.encode("utf-8"))


    def _read_i32(self, offset: int) -> int:
        """从 WASM 线性内存读取一个小端有符号 32 位整数。

        Parameters:
            offset:
                整数在 WASM 线性内存中的字节偏移。

        Returns:
            解码后的 Python 整数。

        Raises:
            SolverRuntimeError:
                指定范围无法从线性内存读取。
        """
        raw = bytes(self._memory.read(self._store, offset, offset + 4))

        if len(raw) != 4:
            raise SolverRuntimeError(
                f"无法从 WASM 内存读取 i32，offset={offset}"
            )

        return struct.unpack("<i", raw)[0]


    def _read_f64(self, offset: int) -> float:
        """从 WASM 线性内存读取一个小端 IEEE-754 双精度浮点数。

        Parameters:
            offset:
                浮点数在 WASM 线性内存中的字节偏移。

        Returns:
            解码后的 Python ``float``。

        Raises:
            SolverRuntimeError:
                指定范围无法从线性内存读取。
        """
        raw = bytes(self._memory.read(self._store, offset, offset + 8))

        if len(raw) != 8:
            raise SolverRuntimeError(
                f"无法从 WASM 内存读取 f64，offset={offset}"
            )

        return struct.unpack("<d", raw)[0]


    @override
    def solve(
        self,
        challenge: Challenge
    ) -> Solution:
        """求解一个 DeepSeekHashV1 工作量证明挑战。

        本方法复现 JavaScript 胶水层调用 ``wasm_solve`` 的过程：

        1. 构造前缀 ``"{salt}_{expireAt}_"``。
        2. 将 ``challenge`` 和前缀按 UTF-8 写入 WASM 内存。
        3. 在 wasm-bindgen 栈上预留 16 字节返回区域。
        4. 使用 ``f64`` 类型的难度值调用 ``wasm_solve``。
        5. 从返回区 ``+0`` 读取状态，从 ``+8`` 读取答案。
        6. 无论调用成功与否，都恢复 wasm-bindgen 栈指针。

        计算密集型搜索由 WASM 完成。Python 主要负责数据验证、算法分派、内存传递和结果封装。

        Parameters:
            challenge:
                已经过基础结构校验的挑战对象。

        Returns:
            WASM 求得的 PoW 答案。其 ABI 类型为 ``f64``。

        Raises:
            ValueError:
                难度无效。
            NoSolutionError:
                WASM 未找到答案，或者返回值不是有限数值。
        """
        salt = challenge.salt
        difficulty = challenge.difficulty
        expire_at = challenge.expire_at
        signature = challenge.signature
        challenge = challenge.challenge

        wasm_difficulty = float(difficulty)

        if not math.isfinite(wasm_difficulty):
            raise ValueError("difficulty 必须是有限数值")

        if wasm_difficulty < 0:
            raise ValueError("difficulty 不能为负数")

        # JavaScript 模板字符串会执行 String(expireAt)。
        prefix = f"{salt}_{expire_at}_"

        challenge_ptr, challenge_len = self._write_utf8(challenge)
        prefix_ptr, prefix_len = self._write_utf8(prefix)

        # wasm-bindgen 使用 16 字节返回区域传递 Option<f64> 一类的结果。
        stack_ret_ptr = int(
            self._add_to_stack_pointer(self._store, -16)
        ) & 0xFFFFFFFF

        try:
            self._wasm_solve(
                self._store,
                stack_ret_ptr,
                challenge_ptr,
                challenge_len,
                prefix_ptr,
                prefix_len,
                wasm_difficulty,
            )

            # 返回区布局与原始 JavaScript 胶水一致：
            # +0: i32 状态，0 表示没有结果
            # +8: f64 答案
            status = self._read_i32(stack_ret_ptr)

            if status == 0:
                raise NoSolutionError(
                    "WASM 未找到 PoW 解: "
                    f"challenge={challenge!r}, "
                    f"difficulty={wasm_difficulty}, "
                    f"prefix={prefix!r}"
                )

            answer = self._read_f64(stack_ret_ptr + 8)

            if not math.isfinite(answer):
                raise NoSolutionError(
                    f"WASM 返回了无效答案: {answer!r}"
                )
        finally:
            # 即使调用或结果读取失败，也必须恢复栈指针。
            self._add_to_stack_pointer(self._store, 16)

        return Solution(
            algorithm=self.name,
            challenge=challenge,
            salt=salt,
            answer=answer,
            signature=signature
        )
