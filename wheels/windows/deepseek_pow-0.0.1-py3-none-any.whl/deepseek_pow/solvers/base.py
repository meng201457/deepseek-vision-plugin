"""
算法实现接口
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from ..backends.base import PowBackend
    from ..models import Challenge, Solution


class BaseSolver(ABC):
    """所有 PoW 算法版本必须实现的抽象接口。
    """

    name: ClassVar[str]

    @abstractmethod
    def solve(
        self,
        challenge: Challenge
    ) -> Solution:
        """使用给定后端求解挑战。

        Parameters:
            challenge:
                已经过基础结构校验的挑战对象。

        Returns:
            求得的 PoW 答案。

        Raises:
            InvalidChallengeError:
                挑战字段不符合该算法的要求。
            NoSolutionError:
                后端未能找到符合条件的答案。
        """
        raise NotImplementedError
