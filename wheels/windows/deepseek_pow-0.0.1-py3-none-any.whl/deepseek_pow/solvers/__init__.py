from .base import BaseSolver
from .deepseek_hash_v1_solver import DeepSeekHashV1Solver

SOLVER_TYPES = [
	DeepSeekHashV1Solver,
]
